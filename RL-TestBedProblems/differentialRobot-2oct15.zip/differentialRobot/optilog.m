DRL

Starting matlabpool using the 'local' profile ... connected to 2 workers.
cumGoals:40.4978; Decay:7; SoftmaxT:1; alpha:0.3
cumGoals:40.8342; Decay:6; SoftmaxT:1.1; alpha:0.3
cumGoals:43.0373; Decay:5; SoftmaxT:1.1; alpha:0.3
cumGoals:42.886; Decay:8; SoftmaxT:1.1; alpha:0.3
cumGoals:43.7605; Decay:9; SoftmaxT:1.1; alpha:0.3
cumGoals:44.0801; Decay:10; SoftmaxT:1.1; alpha:0.3
cumGoals:41.2714; Decay:11; SoftmaxT:1.1; alpha:0.3
cumGoals:42.1123; Decay:12; SoftmaxT:1.1; alpha:0.3
cumGoals:42.3983; Decay:10; SoftmaxT:0.6; alpha:0.3
cumGoals:40.5819; Decay:10; SoftmaxT:0.1; alpha:0.3
cumGoals:42.1292; Decay:10; SoftmaxT:1.6; alpha:0.3
cumGoals:41.2546; Decay:10; SoftmaxT:2.1; alpha:0.3

x =

   10.0000
    1.1000


fval =

  -44.0801

Sending a stop signal to all the workers ... stopped.
Elapsed time is 4270.589982 seconds.


CRL

Starting matlabpool using the 'local' profile ... connected to 2 workers.
cumGoals:40.7333; Decay:7; SoftmaxT:2; alpha:0.5
cumGoals:39.4719; Decay:6; SoftmaxT:2.1; alpha:0.5
cumGoals:38.6478; Decay:5; SoftmaxT:2.1; alpha:0.5
cumGoals:38.9337; Decay:8; SoftmaxT:2.1; alpha:0.5
cumGoals:36.226; Decay:9; SoftmaxT:2.1; alpha:0.5
cumGoals:37.9415; Decay:7; SoftmaxT:1.6; alpha:0.5
cumGoals:38.3956; Decay:7; SoftmaxT:1.1; alpha:0.5
cumGoals:38.5806; Decay:7; SoftmaxT:2.6; alpha:0.5
cumGoals:38.816; Decay:7; SoftmaxT:3.1; alpha:0.5

x =

    7.0000
    2.1000


fval =

  -40.7333

Sending a stop signal to all the workers ... stopped.
Elapsed time is 2881.135628 seconds.



%----------------------------------------



DRL

Sending a stop signal to all the workers ... stopped.
Starting matlabpool using the 'local' profile ... connected to 2 workers.
cumGoals:40.793; Decay:6; SoftmaxT:1; alpha:0.3
cumGoals:37.8696; Decay:5; SoftmaxT:1.1; alpha:0.3
cumGoals:37.5336; Decay:4; SoftmaxT:1.1; alpha:0.3
cumGoals:41.7339; Decay:7; SoftmaxT:1.1; alpha:0.3
cumGoals:38.3401; Decay:8; SoftmaxT:1.1; alpha:0.3
cumGoals:36.996; Decay:9; SoftmaxT:1.1; alpha:0.3
cumGoals:34.5094; Decay:7; SoftmaxT:0.6; alpha:0.3
cumGoals:35.1142; Decay:7; SoftmaxT:0.1; alpha:0.3
cumGoals:39.953; Decay:7; SoftmaxT:1.6; alpha:0.3
cumGoals:37.9032; Decay:7; SoftmaxT:2.1; alpha:0.3
cumGoals:35.3831; Decay:7; SoftmaxT:1.1; alpha:0.2
cumGoals:31.4516; Decay:7; SoftmaxT:1.1; alpha:0.1
cumGoals:39.4825; Decay:7; SoftmaxT:1.1; alpha:0.4
cumGoals:36.2567; Decay:7; SoftmaxT:1.1; alpha:0.5

x =

    7.0000
    1.1000
    0.3000


fval =

  -41.7339

Sending a stop signal to all the workers ... stopped.
Elapsed time is 2918.582838 seconds.


CRL

Starting matlabpool using the 'local' profile ... connected to 2 workers.
cumGoals:32.5269; Decay:6; SoftmaxT:2; alpha:0.3
cumGoals:31.5188; Decay:5; SoftmaxT:2.1; alpha:0.3
cumGoals:31.082; Decay:4; SoftmaxT:2.1; alpha:0.3
cumGoals:30.578; Decay:7; SoftmaxT:2.1; alpha:0.3
cumGoals:31.586; Decay:8; SoftmaxT:2.1; alpha:0.3
cumGoals:31.922; Decay:6; SoftmaxT:1.6; alpha:0.3
cumGoals:31.2164; Decay:6; SoftmaxT:1.1; alpha:0.3
cumGoals:31.4516; Decay:6; SoftmaxT:2.6; alpha:0.3
cumGoals:30.578; Decay:6; SoftmaxT:3.1; alpha:0.3
cumGoals:25.8065; Decay:6; SoftmaxT:2.1; alpha:0.2
cumGoals:19.7245; Decay:6; SoftmaxT:2.1; alpha:0.1
cumGoals:33.9046; Decay:6; SoftmaxT:2.1; alpha:0.4
cumGoals:33.4677; Decay:6; SoftmaxT:2.1; alpha:0.5
cumGoals:35.2151; Decay:6; SoftmaxT:2.1; alpha:0.6
cumGoals:33.3333; Decay:6; SoftmaxT:2.1; alpha:0.7
cumGoals:36.5927; Decay:5; SoftmaxT:2.1; alpha:0.6
cumGoals:33.5685; Decay:4; SoftmaxT:2.1; alpha:0.6
cumGoals:31.4852; Decay:7; SoftmaxT:2.1; alpha:0.6
cumGoals:34.3414; Decay:8; SoftmaxT:2.1; alpha:0.6
cumGoals:33.3333; Decay:3; SoftmaxT:2.1; alpha:0.6
cumGoals:33.7366; Decay:5; SoftmaxT:1.6; alpha:0.6
cumGoals:33.9718; Decay:5; SoftmaxT:1.1; alpha:0.6
cumGoals:34.9126; Decay:5; SoftmaxT:2.6; alpha:0.6
cumGoals:33.2325; Decay:5; SoftmaxT:3.1; alpha:0.6
cumGoals:37.668; Decay:5; SoftmaxT:2.1; alpha:0.5
cumGoals:32.9637; Decay:5; SoftmaxT:2.1; alpha:0.4
cumGoals:32.3253; Decay:5; SoftmaxT:2.1; alpha:0.7
cumGoals:33.0309; Decay:4; SoftmaxT:2.1; alpha:0.5
cumGoals:34.4086; Decay:3; SoftmaxT:2.1; alpha:0.5
cumGoals:34.3414; Decay:7; SoftmaxT:2.1; alpha:0.5
cumGoals:34.3078; Decay:5; SoftmaxT:1.6; alpha:0.5
cumGoals:35.8199; Decay:5; SoftmaxT:1.1; alpha:0.5
cumGoals:34.9798; Decay:5; SoftmaxT:2.6; alpha:0.5
cumGoals:34.375; Decay:5; SoftmaxT:3.1; alpha:0.5

x =

    5.0000
    2.1000
    0.5000


fval =

  -37.6680

Sending a stop signal to all the workers ... stopped.
Elapsed time is 5941.840658 seconds.

%------------------------

DRL

Starting matlabpool using the 'local' profile ... Warning: Found 1 pre-existing communicating job(s) created by matlabpool
that are running. You can use 'matlabpool close force local' to remove
all jobs created by matlabpool. 
> In InteractiveClient>InteractiveClient.pRemoveOldJobs at 426
  In InteractiveClient>InteractiveClient.start at 260
  In MatlabpoolHelper>MatlabpoolHelper.doOpen at 363
  In MatlabpoolHelper>MatlabpoolHelper.doMatlabpool at 137
  In matlabpool at 139
  In runOptimiaztion at 17 
connected to 2 workers.
cumGoals:55.08; Decay:6; alpha:0.3; lambda:0.9; SoftmaxT:2
cumGoals:57.24; Decay:5; alpha:0.3; lambda:0.9; SoftmaxT:2.1
cumGoals:59.24; Decay:4; alpha:0.3; lambda:0.9; SoftmaxT:2.1
cumGoals:55.46; Decay:7; alpha:0.3; lambda:0.9; SoftmaxT:2.1
cumGoals:52.06; Decay:8; alpha:0.3; lambda:0.9; SoftmaxT:2.1
cumGoals:55.44; Decay:3; alpha:0.3; lambda:0.9; SoftmaxT:2.1
cumGoals:56.74; Decay:4; alpha:0.3; lambda:0.9; SoftmaxT:1.6
cumGoals:54.14; Decay:4; alpha:0.3; lambda:0.9; SoftmaxT:1.1
cumGoals:54.1; Decay:4; alpha:0.3; lambda:0.9; SoftmaxT:2.6
cumGoals:55.88; Decay:4; alpha:0.3; lambda:0.9; SoftmaxT:3.1
cumGoals:51.52; Decay:4; alpha:0.2; lambda:0.9; SoftmaxT:2.1
cumGoals:56.76; Decay:4; alpha:0.1; lambda:0.9; SoftmaxT:2.1
cumGoals:62.5; Decay:4; alpha:0.4; lambda:0.9; SoftmaxT:2.1
cumGoals:52.36; Decay:4; alpha:0.5; lambda:0.9; SoftmaxT:2.1
cumGoals:53.78; Decay:4; alpha:0.6; lambda:0.9; SoftmaxT:2.1
cumGoals:60.34; Decay:3; alpha:0.4; lambda:0.9; SoftmaxT:2.1
cumGoals:60.82; Decay:5; alpha:0.4; lambda:0.9; SoftmaxT:2.1
cumGoals:53.5; Decay:6; alpha:0.4; lambda:0.9; SoftmaxT:2.1
cumGoals:50.78; Decay:4; alpha:0.4; lambda:0.9; SoftmaxT:1.6
cumGoals:59.74; Decay:4; alpha:0.4; lambda:0.9; SoftmaxT:1.1
cumGoals:59.44; Decay:4; alpha:0.4; lambda:0.9; SoftmaxT:2.6
cumGoals:51.54; Decay:4; alpha:0.4; lambda:0.9; SoftmaxT:3.1

x =

    4.0000
    2.1000
    0.4000


fval =

  -62.5000
  
  

Starting matlabpool using the 'local' profile ... connected to 2 workers.
cumGoals:52.2333; Decay:8; alpha:0.3; lambda:0.9; SoftmaxT:1
cumGoals:53.0333; Decay:7; alpha:0.3; lambda:0.9; SoftmaxT:1.1
cumGoals:56.5; Decay:6; alpha:0.3; lambda:0.9; SoftmaxT:1.1
cumGoals:53.9333; Decay:9; alpha:0.3; lambda:0.9; SoftmaxT:1.1
cumGoals:52.4333; Decay:10; alpha:0.3; lambda:0.9; SoftmaxT:1.1
cumGoals:53.6667; Decay:5; alpha:0.3; lambda:0.9; SoftmaxT:1.1
cumGoals:52.1333; Decay:4; alpha:0.3; lambda:0.9; SoftmaxT:1.1
cumGoals:56.9; Decay:6; alpha:0.3; lambda:0.9; SoftmaxT:0.6
cumGoals:62.3667; Decay:6; alpha:0.3; lambda:0.9; SoftmaxT:0.1
cumGoals:54.2333; Decay:6; alpha:0.3; lambda:0.9; SoftmaxT:1.6
cumGoals:50.8; Decay:6; alpha:0.3; lambda:0.9; SoftmaxT:2.1
cumGoals:50.8333; Decay:6; alpha:0.2; lambda:0.9; SoftmaxT:0.1
cumGoals:50.2667; Decay:6; alpha:0.1; lambda:0.9; SoftmaxT:0.1
cumGoals:58.2333; Decay:6; alpha:0.4; lambda:0.9; SoftmaxT:0.1
cumGoals:53.1333; Decay:6; alpha:0.5; lambda:0.9; SoftmaxT:0.1
cumGoals:56.7; Decay:6; alpha:0.3; lambda:0.8; SoftmaxT:0.1
cumGoals:48.2333; Decay:6; alpha:0.3; lambda:0.7; SoftmaxT:0.1
cumGoals:58.5333; Decay:5; alpha:0.3; lambda:0.9; SoftmaxT:0.1
cumGoals:59.7; Decay:4; alpha:0.3; lambda:0.9; SoftmaxT:0.1
cumGoals:56.3667; Decay:7; alpha:0.3; lambda:0.9; SoftmaxT:0.1
cumGoals:53.8667; Decay:8; alpha:0.3; lambda:0.9; SoftmaxT:0.1

x =

    6.0000
    0.1000
    0.3000
    0.9000


fval =

  -62.3667
  

CRL

Starting matlabpool using the 'local' profile ... connected to 2 workers.
cumGoals:50.1; Decay:5; alpha:0.3; lambda:0.9; SoftmaxT:2
cumGoals:47.5333; Decay:4; alpha:0.3; lambda:0.9; SoftmaxT:2.1
cumGoals:49.9667; Decay:3; alpha:0.3; lambda:0.9; SoftmaxT:2.1
cumGoals:48.9667; Decay:6; alpha:0.3; lambda:0.9; SoftmaxT:2.1
cumGoals:45.3667; Decay:7; alpha:0.3; lambda:0.9; SoftmaxT:2.1
cumGoals:49.3667; Decay:5; alpha:0.3; lambda:0.9; SoftmaxT:1.6
cumGoals:48.8333; Decay:5; alpha:0.3; lambda:0.9; SoftmaxT:1.1
cumGoals:46.4333; Decay:5; alpha:0.3; lambda:0.9; SoftmaxT:2.6
cumGoals:51.2333; Decay:5; alpha:0.3; lambda:0.9; SoftmaxT:3.1
cumGoals:47.4; Decay:5; alpha:0.3; lambda:0.9; SoftmaxT:3.6
cumGoals:51.4333; Decay:5; alpha:0.3; lambda:0.9; SoftmaxT:4.1
cumGoals:54.8667; Decay:5; alpha:0.3; lambda:0.9; SoftmaxT:4.6
cumGoals:44.6333; Decay:5; alpha:0.2; lambda:0.9; SoftmaxT:4.6
cumGoals:36.7667; Decay:5; alpha:0.1; lambda:0.9; SoftmaxT:4.6
cumGoals:45.8; Decay:5; alpha:0.4; lambda:0.9; SoftmaxT:4.6
cumGoals:51.5; Decay:5; alpha:0.5; lambda:0.9; SoftmaxT:4.6
cumGoals:44.2667; Decay:5; alpha:0.3; lambda:0.8; SoftmaxT:4.6
cumGoals:44.2333; Decay:5; alpha:0.3; lambda:0.7; SoftmaxT:4.6
cumGoals:48.6333; Decay:4; alpha:0.3; lambda:0.9; SoftmaxT:4.6
cumGoals:50.5; Decay:3; alpha:0.3; lambda:0.9; SoftmaxT:4.6
cumGoals:47.2333; Decay:6; alpha:0.3; lambda:0.9; SoftmaxT:4.6
cumGoals:48.7; Decay:7; alpha:0.3; lambda:0.9; SoftmaxT:4.6

x =

    5.0000
    4.6000
    0.3000
    0.9000


fval =

  -54.8667