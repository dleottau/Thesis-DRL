function q = getQvalue(Qa, FV)

q = sum(FV.*Qa)/sum(FV);